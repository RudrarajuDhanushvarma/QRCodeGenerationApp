# QR Code Generator (Spring Boot)

Simple Spring Boot project that generates a QR code for a given URL.

## Features
- Enter a URL in the frontend (index.html).
- Backend generates a PNG QR code using ZXing.
- Scan the QR code with your phone camera / Google Lens — it will open the provided URL.

## How to run
1. Prerequisites: Java 17+, Maven.
2. Build and run:
```bash
cd qrcode-generator
mvn spring-boot:run
```
3. Open `http://localhost:8080/` in your browser.

## Endpoints
- `POST /generate` - form-url-encoded with `url` (required) and `size` (optional, default 300). Returns `image/png`.

## Notes
- Project includes Lombok (used for logging with `@Slf4j`). Install Lombok plugin in your IDE for better experience.
