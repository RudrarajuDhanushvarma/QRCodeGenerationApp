package com.example.qrcode.dto;

public class QrRequest {
    private String url;
    private Integer size = 300;

    public QrRequest() {}

    public QrRequest(String url, Integer size) {
        this.url = url;
        this.size = size;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Integer getSize() {
        return size;
    }

    public void setSize(Integer size) {
        this.size = size;
    }
}